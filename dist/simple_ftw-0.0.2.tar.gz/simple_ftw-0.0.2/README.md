# ftw package

This is my first package published to pypi, so for now contains nothing excitng... watch this space
